package com.cuni.mff.java;

import org.jetbrains.annotations.NotNull;

import java.io.*;
import java.util.ArrayList;


class Justify2
{
    int sizeLineStandard;
    Justify2(int inSize){sizeLineStandard = inSize;}
    //Justify(String inS){originalLine = inS}

    public static String repeat(String str, int times) {
        return new String(new char[times]).replace("\0", str);
    }


    public String justify(String toBeJustified,int noOfWords)
    {
        if(toBeJustified.length() == sizeLineStandard)
            return toBeJustified;
        if(noOfWords==1)
            return  toBeJustified;
        int noOfSpaces = noOfWords-1;
        StringBuffer  toBeJustifiedBuffer = new StringBuffer(toBeJustified).reverse();
        toBeJustifiedBuffer.ensureCapacity(sizeLineStandard);

        int spacesToAdd = (sizeLineStandard - toBeJustifiedBuffer.length())/noOfSpaces;
        //System.out.println(spacesToAdd);
        String space = " ";
        if(spacesToAdd != 0)
            space = this.repeat(space,spacesToAdd);
        for (int i = toBeJustifiedBuffer.length() - 1; i >= 1 && toBeJustifiedBuffer.length() < sizeLineStandard; i--) {
            if (toBeJustifiedBuffer.charAt(i) != ' ' && toBeJustifiedBuffer.charAt(i-1) == ' ')
                toBeJustifiedBuffer.insert(i, space);
        }

        for (int i = toBeJustifiedBuffer.length() - 1; i >= 1 && toBeJustifiedBuffer.length() < sizeLineStandard; i--) {
            if (toBeJustifiedBuffer.charAt(i) != ' ' && toBeJustifiedBuffer.charAt(i-1) == ' ')
                toBeJustifiedBuffer.insert(i, ' ');
        }
        return  toBeJustifiedBuffer.reverse().toString();

    }

    public String justify(String toBeJustified)
    {
        StringBuffer  toBeJustifiedBuffer = new StringBuffer(toBeJustified).reverse();
        toBeJustifiedBuffer.ensureCapacity(sizeLineStandard);
        while(toBeJustifiedBuffer.length() < sizeLineStandard) {
            for (int i = toBeJustifiedBuffer.length() - 1; i >= 1 && toBeJustifiedBuffer.length() < sizeLineStandard; i--) {
                if (toBeJustifiedBuffer.charAt(i) != ' ' && toBeJustifiedBuffer.charAt(i-1) == ' ')
                    toBeJustifiedBuffer.insert(i, ' ');
            }
        }
        return  toBeJustifiedBuffer.reverse().toString();
    }

}

public class Main2 {
    public static void main(String argv[]) {
        String output ="";
        String numString = "";
        String word = "";
        int numMaxLine = 0;
        try(BufferedReader input = new BufferedReader(new InputStreamReader(System.in)))
        {
            int c;
            while((c = input.read()) != -1 && (char)c != '\n')
            {
                numString += (char)c;
            }
            numMaxLine = Integer.parseInt(numString);
            Justify2 justifier = new Justify2(numMaxLine);
            Boolean isParagraph = false;
            int noOfWords = 0;
            while((c = input.read()) != -1)
            {
                if(Character.isWhitespace((char)c))
                {
                    if(isParagraph)
                        continue;
                    if(word.equals("")&& (char) c == '\n')
                    {
                        isParagraph = true;
                        System.out.println(output);
                        System.out.println();
                        output = "";
                        noOfWords = 0;
                        continue;
                    }
                    if(output.length() + word.length() + 1<= numMaxLine)
                    {
                        if(output.length() == 0)
                            output += word;
                        else
                            output += " " +  word;
                        noOfWords++;
                    }
                    else
                    {
                        if(output.equals("")) {
                            output = word;
                            noOfWords = 1;
                            System.out.println(output);
                            output = "";
                        }
                        else {
                            if (noOfWords == 1)
                                System.out.println(output);
                            else
                                System.out.println(justifier.justify(output, noOfWords));
                            output = word;
                            noOfWords = 1;
                        }
                    }
                    word = "";

                }
                else {
                    isParagraph = false;
                    word += (char) c;
                }
            }
            System.out.println(output);
        }
        catch (NumberFormatException e)
        {
            System.out.println("Error");
        }
        catch (IOException e)
        {

        }
    }
}