package com.cuni.mff.java;

import java.util.Arrays;

public class LogCollectionArray implements MyCollection{
    Printer[] elements = new Printer[16];
    int size = 0;
    @Override
    public void add(Object o) {
        if(size == elements.length){
            this.resize();
        }
        this.elements[this.size] = (Printer) o;
        this.size++;
    }
    private void resize()
    {
        elements = Arrays.copyOf(elements,elements.length*2);
    }

    @Override
    public Object get(int i) {
        if(i >= elements.length)
            throw new IndexOutOfBoundsException("On that position there was no existing item");
        return elements[i];
    }

    @Override
    public void remove(Object o) {

    }

    @Override
    public void remove(int i) {
        if(i >= elements.length)
            throw new IndexOutOfBoundsException("On that position there was no existing item");
        for(int idx = i; idx < this.size-1; i++)
            elements[i] = elements[i+1];
        this.size--;
    }

    @Override
    public int getSize() {
        return this.size;
    }
}
