package com.cuni.mff.java;


public class Main {


    public static void main(String[] args) {
            UI newUI = new UI();
            newUI.run();
    }

}
