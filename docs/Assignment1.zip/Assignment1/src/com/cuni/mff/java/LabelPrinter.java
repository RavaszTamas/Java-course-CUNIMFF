package com.cuni.mff.java;

public class LabelPrinter extends GenericPrinter {

    private String label;
    LabelPrinter()
    {
        this("default");
    }
    LabelPrinter(String labelParam)
    {
        System.out.println("Creating LabelPrinter");
        this.label = labelParam;
    }
    public void print(String msg)
    {
        System.out.println(this.label + ": " + msg);
    }

}
