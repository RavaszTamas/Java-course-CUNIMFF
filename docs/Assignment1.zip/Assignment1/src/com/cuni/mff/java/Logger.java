package com.cuni.mff.java;

public class Logger {
    Printer currentPrinter = null;
    int currentLevel = 0;
   // MyCollection storage = new LogCollectionLinkedList();
    MyCollection storage = new LogCollectionArray();

    public void addPrinter(Printer p) {
        storage.add(p);

        //this.currentPrinter = p;
    }
    public void log(int level,String msg){
        if( storage.getSize() > 0){
            if(level >= this.currentLevel) {
                for (int i = 0; i < storage.getSize(); i++) {
                    Printer pr = (Printer) storage.get(i);
                    pr.print(msg);
                }
            }
            //currentPrinter.print(msg);
        }
        else{
            throw new NullPointerException("No printer is set for the logger!");
        }
    }
    public void setCurrentLevel(int level){
        this.currentLevel = level;
    }
}
