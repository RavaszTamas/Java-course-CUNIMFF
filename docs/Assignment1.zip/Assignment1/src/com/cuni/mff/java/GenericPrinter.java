package com.cuni.mff.java;

public class GenericPrinter implements Printer {
    GenericPrinter()
    {
        System.out.println("Creating GenericPrinter");
    }
    public void print(String msg)
    {
        System.out.println(msg);
    }
}