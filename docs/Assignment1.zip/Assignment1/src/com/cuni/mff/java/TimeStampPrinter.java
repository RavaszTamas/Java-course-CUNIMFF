package com.cuni.mff.java;

public class TimeStampPrinter extends GenericPrinter {
    TimeStampPrinter()
    {
        System.out.println("Creating TimeStampPrinter");
    }
    public void print(String msg){
        System.out.println((new java.util.Date()) + " "+ msg);
    }
}
